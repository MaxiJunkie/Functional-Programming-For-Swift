import UIKit

class ClassA {

    var onTap: (() -> Void)?
  

}

class ClassB {
    
    var b = 0
    var a = ClassA()
    
    func setupMemoryLeak() {
        
        a.onTap = { [weak self] in
            self?.b = 1
        }
        
    }
    
    deinit {
        print("deinitB")
    }
   
}

class ClassC {
    
    var c = 0
    var a = ClassA()
    
    func setupMemoryLeak() {
        
        func setupC() {
            c = 1
        }
        
        a.onTap = {
            setupC()
        }
        
    }
    
    deinit {
        print("deinitC")
    }
    
}


func testB() {
    
    let b = ClassB()
    b.setupMemoryLeak()
    
}

testB()

func testC() {
    
    let c = ClassC()
    c.setupMemoryLeak()
    
}

testC()
