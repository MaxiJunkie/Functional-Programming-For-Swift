 
import UIKit


struct Parser<Result> {
    let parse: (Substring) -> (Result, Substring)?
}

func character(matching condition: @escaping(Character) -> Bool) -> Parser<Character> {
    
    return Parser(parse: { input in
        guard let char = input.first, condition(char) else { return nil }
        return (char, input.dropFirst())
    })
    
}

let one = character { $0 == "1" }
one.parse("1234")

extension CharacterSet {
    
    func contains(_ c: Character) -> Bool {
    
        let scalars = String(c).unicodeScalars
        guard scalars.count == 1 else { return false }
        return contains(scalars.first!)
    }
        
 }

 let digit = character { CharacterSet.decimalDigits.contains($0) }

 extension Parser {

    var many: Parser<[Result]> {
        
        return Parser<[Result]>(parse: { input in
            
            var result: [Result] = []
            var reminder = input
           
            while let(element, newReminder) = self.parse(reminder) {
                result.append(element)
                reminder = newReminder
            }
            
            return (result, reminder)
        })
        
    }
    
 }
 
 extension Parser {
    
    func map<T>(_ transform: @escaping (Result) -> T) -> Parser<T> {
    
        return Parser<T>(parse: { input in
            
            guard let (result, reminder) = self.parse(input) else { return nil }
            return (transform(result), reminder)
        })
    
    }
 }

 
 extension Parser {
 
    
    func followed<A>(by other: Parser<A>) -> Parser<(Result, A)> {
        
        return Parser<(Result, A)>(parse: { input in
         
            guard let (result1, reminder1) = self.parse(input),
                  let (result2, reminder2) = other.parse(reminder1)  else { return nil }
            
            return ((result1, result2), reminder2)
        })
    
    }
        
 }
 
 let integer = digit.many.map { Int(String($0))! }
 print(integer)
 let multiplication = integer
    .followed(by: character { $0 == "*" })
    .followed(by: integer)
 

 let mult2 = multiplication.map { $0.0 * $1 }

 func curriedMultiply(_ x: Int) -> (Character) -> (Int) -> Int {
    
    return { op in
        return { y in
            return x * y
        }
    }
 }

 let digit2 = character { CharacterSet.decimalDigits.contains($0) }
 let integer2 = digit2.many.map {
    
    return Int(String($0))! }
 
 let p1 = integer2.map(curriedMultiply)

 let p2 = p1.followed(by: character { $0 == "*" })
 let p3 = p2.map { f, op in f(op) }
 let p4 = p3.followed(by: integer2)
 let p5 = p4.map { f, y in f(y) }

 print(p5.parse("2*6"))

 
 func add1(_ x: Int, _ y: Int) -> Int {
    
    return x + y
 }
 
 func add2(_ x: Int) -> ((Int) -> Int) {
    return { y in x + y }
 }
 
 func add3(_ x: Int) -> (Int) -> (Int) -> Int {
    return { y in
        
        let a = y + x
        
        return { z in

            return a + z
            
        }
        
    }
 }
 
 func curry<A, B, C>(_ f: @escaping (A, B) -> C) -> (A) -> (B) -> C {
    return { a in { b in f(a, b) } }
 }

 func >> <A, B>(_ a: A, f: @escaping (A) -> B) -> B {
    return f(a)
 }
 
 
 
 print(add1(4, 4))
 print(add3(3)(3)(3))
